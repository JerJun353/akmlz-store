let currentData = null;

function esc(str) {
  const div = document.createElement("div");
  div.textContent = str == null ? "" : String(str);
  return div.innerHTML;
}

function showToast(message, isError) {
  const toast = document.getElementById("admin-toast");
  toast.textContent = message;
  toast.style.borderColor = isError ? "#ff6b6b" : "";
  toast.classList.add("show");
  clearTimeout(window.__toastTimer);
  window.__toastTimer = setTimeout(() => toast.classList.remove("show"), 3000);
}

async function api(url, options) {
  const res = await fetch(url, Object.assign({ credentials: "same-origin" }, options));
  let body = null;
  try {
    body = await res.json();
  } catch (e) {
    /* no body */
  }
  if (!res.ok) {
    const message = (body && body.error) || "Terjadi kesalahan (" + res.status + ")";
    throw new Error(message);
  }
  return body;
}

// ============================================================
// AUTH
// ============================================================
async function checkSession() {
  try {
    const data = await api("/api/admin/session");
    if (data.isAdmin) {
      showAdminApp();
    } else {
      showLoginScreen();
    }
  } catch (e) {
    showLoginScreen();
  }
}

function showLoginScreen() {
  document.getElementById("login-screen").hidden = false;
  document.getElementById("admin-app").hidden = true;
}

function showAdminApp() {
  document.getElementById("login-screen").hidden = true;
  document.getElementById("admin-app").hidden = false;
  loadAll();
}

document.getElementById("login-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const password = document.getElementById("login-password").value;
  const errorEl = document.getElementById("login-error");
  errorEl.textContent = "";
  try {
    await api("/api/admin/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ password }),
    });
    document.getElementById("login-password").value = "";
    showAdminApp();
  } catch (err) {
    errorEl.textContent = err.message;
  }
});

document.getElementById("logout-btn").addEventListener("click", async () => {
  try {
    await api("/api/admin/logout", { method: "POST" });
  } catch (e) {
    /* ignore */
  }
  showLoginScreen();
});

// ============================================================
// TABS
// ============================================================
document.querySelectorAll(".admin-tab").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".admin-tab").forEach((b) => b.classList.remove("active"));
    document.querySelectorAll(".admin-tab-panel").forEach((p) => (p.hidden = true));
    btn.classList.add("active");
    document.getElementById(btn.dataset.tab).hidden = false;
  });
});

// ============================================================
// LOAD DATA
// ============================================================
async function loadAll() {
  try {
    const res = await fetch("/api/products");
    currentData = await res.json();
  } catch (e) {
    showToast("Gagal memuat data toko", true);
    return;
  }

  document.getElementById("login-logo").src = currentData.shop.logo || "";
  document.getElementById("admin-logo").src = currentData.shop.logo || "";

  renderProductList("list-blox", "bloxFruit", currentData.bloxFruit);
  renderProductList("list-other", "otherGames", currentData.otherGames);
  renderStockRows(currentData.fruitStock);
  fillSettingsForm(currentData.shop, currentData.joki);
}

// ============================================================
// PRODUCTS — list + edit + delete
// ============================================================
function renderProductList(elId, category, products) {
  const el = document.getElementById(elId);
  if (!products || !products.length) {
    el.innerHTML = '<p class="loading-text">Belum ada produk.</p>';
    return;
  }
  el.innerHTML = products
    .map((p) => {
      const thumb = p.image
        ? '<img class="product-row__thumb" src="' + esc(p.image) + '" alt="">'
        : '<div class="product-row__thumb--empty">No photo</div>';
      const metaBits = [p.game, p.price].filter(Boolean).join(" · ");
      return (
        '<div class="product-row" data-id="' +
        esc(p.id) +
        '" data-category="' +
        category +
        '">' +
        thumb +
        '<div class="product-row__body">' +
        '<p class="product-row__name">' +
        esc(p.name) +
        "</p>" +
        '<p class="product-row__meta">' +
        esc(metaBits) +
        "</p>" +
        '<div class="edit-panel" hidden></div>' +
        "</div>" +
        '<div class="product-row__actions">' +
        '<button type="button" class="edit-btn">Edit</button>' +
        '<button type="button" class="danger delete-btn">Hapus</button>' +
        "</div>" +
        "</div>"
      );
    })
    .join("");

  el.querySelectorAll(".delete-btn").forEach((btn) => {
    btn.addEventListener("click", onDeleteProduct);
  });
  el.querySelectorAll(".edit-btn").forEach((btn) => {
    btn.addEventListener("click", onToggleEdit);
  });
}

function findProduct(category, id) {
  return (currentData[category] || []).find((p) => p.id === id);
}

function onToggleEdit(e) {
  const row = e.target.closest(".product-row");
  const panel = row.querySelector(".edit-panel");
  const category = row.dataset.category;
  const id = row.dataset.id;

  if (!panel.hidden) {
    panel.hidden = true;
    panel.innerHTML = "";
    return;
  }

  const product = findProduct(category, id);
  if (!product) return;

  panel.innerHTML = buildEditFormHtml(category, product);
  panel.hidden = false;

  const form = panel.querySelector("form");
  form.addEventListener("submit", (ev) => onSubmitEdit(ev, category, id));
}

function buildEditFormHtml(category, product) {
  const gameField =
    category === "otherGames"
      ? '<label>Nama game<input type="text" name="game" value="' + esc(product.game || "") + '"></label>'
      : "";
  return (
    '<form class="product-form">' +
    '<div class="form-grid">' +
    gameField +
    '<label>Nama produk<input type="text" name="name" value="' + esc(product.name || "") + '" required></label>' +
    '<label>Harga<input type="text" name="price" value="' + esc(product.price || "") + '" required></label>' +
    '<label>Harga asli (opsional)<input type="text" name="originalPrice" value="' + esc(product.originalPrice || "") + '"></label>' +
    '<label>Label diskon (opsional)<input type="text" name="discountLabel" value="' + esc(product.discountLabel || "") + '"></label>' +
    "</div>" +
    '<label>Catatan (satu baris = satu poin)<textarea name="notes" rows="3">' +
    esc((product.notes || []).join("\n")) +
    "</textarea></label>" +
    '<label>Ganti foto (kosongkan jika tidak diganti)<input type="file" name="image" accept="image/*"></label>' +
    (product.image
      ? '<label class="checkbox-row"><input type="checkbox" name="removeImage" value="true" style="width:auto;"> Hapus foto saat ini</label>'
      : "") +
    '<div style="display:flex; gap:10px;">' +
    '<button type="submit" class="btn-primary">Simpan perubahan</button>' +
    "</div>" +
    "</form>"
  );
}

async function onSubmitEdit(e, category, id) {
  e.preventDefault();
  const form = e.target;
  const formData = new FormData(form);
  try {
    await api("/api/admin/products/" + category + "/" + id, {
      method: "PUT",
      body: formData,
    });
    showToast("Produk berhasil diperbarui");
    await loadAll();
  } catch (err) {
    showToast(err.message, true);
  }
}

async function onDeleteProduct(e) {
  const row = e.target.closest(".product-row");
  const category = row.dataset.category;
  const id = row.dataset.id;
  const product = findProduct(category, id);
  const ok = window.confirm('Hapus produk "' + (product ? product.name : id) + '"? Tindakan ini tidak bisa dibatalkan.');
  if (!ok) return;

  try {
    await api("/api/admin/products/" + category + "/" + id, { method: "DELETE" });
    showToast("Produk dihapus");
    await loadAll();
  } catch (err) {
    showToast(err.message, true);
  }
}

// ============================================================
// PRODUCTS — add new
// ============================================================
function setupAddForm(formId) {
  const form = document.getElementById(formId);
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const category = form.dataset.category;
    const formData = new FormData(form);
    formData.append("category", category);
    try {
      await api("/api/admin/products", { method: "POST", body: formData });
      showToast("Produk ditambahkan");
      form.reset();
      await loadAll();
    } catch (err) {
      showToast(err.message, true);
    }
  });
}
setupAddForm("form-add-blox");
setupAddForm("form-add-other");

// ============================================================
// STOCK FRUIT
// ============================================================
function renderStockRows(fruitStock) {
  const container = document.getElementById("stock-rows");
  container.innerHTML = "";
  (fruitStock || []).forEach((item) => addStockRow(item));
}

function addStockRow(item) {
  const container = document.getElementById("stock-rows");
  const row = document.createElement("div");
  row.className = "stock-row";
  row.innerHTML =
    '<input type="text" placeholder="Nama fruit" value="' + esc((item && item.name) || "") + '" data-field="name">' +
    '<input type="text" placeholder="Stok (contoh 4x)" value="' + esc((item && item.qty) || "") + '" data-field="qty">' +
    '<input type="text" placeholder="Harga (contoh 4K)" value="' + esc((item && item.price) || "") + '" data-field="price">' +
    '<button type="button" title="Hapus baris">✕</button>';
  row.querySelector("button").addEventListener("click", () => row.remove());
  container.appendChild(row);
}

document.getElementById("stock-add-row").addEventListener("click", () => addStockRow(null));

document.getElementById("stock-save").addEventListener("click", async () => {
  const rows = Array.from(document.querySelectorAll(".stock-row")).map((row) => ({
    name: row.querySelector('[data-field="name"]').value.trim(),
    qty: row.querySelector('[data-field="qty"]').value.trim(),
    price: row.querySelector('[data-field="price"]').value.trim(),
  })).filter((r) => r.name);

  const statusEl = document.getElementById("stock-save-status");
  try {
    await api("/api/admin/stock", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ fruitStock: rows }),
    });
    statusEl.textContent = "Tersimpan ✓";
    showToast("Stock fruit diperbarui");
    setTimeout(() => (statusEl.textContent = ""), 2000);
    await loadAll();
  } catch (err) {
    showToast(err.message, true);
  }
});

// ============================================================
// SETTINGS
// ============================================================
function fillSettingsForm(shop, joki) {
  document.getElementById("set-name").value = shop.name || "";
  document.getElementById("set-contact").value = shop.contact || "";
  document.getElementById("set-hero-title").value = shop.heroTitle || "";
  document.getElementById("set-hero-sub").value = shop.heroSub || "";
  document.getElementById("set-payment-rule").value = shop.paymentRule || "";

  document.getElementById("set-joki-title").value = (joki && joki.title) || "";
  document.getElementById("set-joki-desc").value = (joki && joki.description) || "";
  document.getElementById("set-joki-flow").value = ((joki && joki.flow) || []).join("\n");
}

document.getElementById("settings-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const formData = new FormData(e.target);
  try {
    await api("/api/admin/settings", { method: "PUT", body: formData });
    showToast("Pengaturan toko disimpan");
    await loadAll();
  } catch (err) {
    showToast(err.message, true);
  }
});

document.getElementById("joki-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const formData = new FormData(e.target);
  try {
    await api("/api/admin/settings", { method: "PUT", body: formData });
    showToast("Jasa joki disimpan");
    await loadAll();
  } catch (err) {
    showToast(err.message, true);
  }
});

// ============================================================
// INIT
// ============================================================
checkSession();
