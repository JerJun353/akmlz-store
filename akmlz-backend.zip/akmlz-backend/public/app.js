const WA_SVG =
  '<svg viewBox="0 0 32 32" width="15" height="15" fill="currentColor"><path d="M16.02 3C9.4 3 4 8.36 4 14.94c0 2.23.6 4.32 1.66 6.12L3 29l8.16-2.6a12.9 12.9 0 0 0 4.86.95h.01c6.62 0 12.02-5.36 12.02-11.94C28.05 8.36 22.65 3 16.02 3zm0 21.75h-.01a10.2 10.2 0 0 1-4.53-1.06l-.32-.17-4.85 1.55 1.58-4.72-.21-.33a9.68 9.68 0 0 1-1.53-5.13C6.15 9.53 10.6 5.1 16.03 5.1c2.62 0 5.09 1.02 6.94 2.87a9.63 9.63 0 0 1 2.87 6.93c0 5.44-4.45 9.86-9.82 9.86zm5.62-7.38c-.3-.15-1.8-.89-2.08-.99-.28-.1-.48-.15-.68.15-.2.3-.78.99-.96 1.19-.18.2-.35.22-.65.07-.3-.15-1.28-.47-2.44-1.5-.9-.8-1.51-1.79-1.68-2.09-.18-.3-.02-.46.13-.61.13-.13.3-.35.44-.52.15-.18.2-.3.3-.5.1-.2.05-.37-.02-.52-.08-.15-.68-1.64-.94-2.24-.25-.6-.5-.5-.68-.51h-.58c-.2 0-.52.07-.79.37-.27.3-1.04 1.02-1.04 2.48 0 1.46 1.07 2.87 1.22 3.07.15.2 2.1 3.2 5.08 4.49.71.31 1.26.49 1.69.62.71.23 1.35.2 1.86.12.57-.08 1.8-.73 2.05-1.44.25-.71.25-1.31.18-1.44-.07-.13-.27-.2-.57-.35z"/></svg>';

function waLink(contact, text) {
  return "https://wa.me/" + contact + (text ? "?text=" + encodeURIComponent(text) : "");
}

function esc(str) {
  const div = document.createElement("div");
  div.textContent = str == null ? "" : String(str);
  return div.innerHTML;
}

function renderProductCard(p, contact) {
  const imgHtml = p.image
    ? '<img src="' + esc(p.image) + '" alt="' + esc(p.name) + '" loading="lazy">'
    : "<span>Foto belum ada</span>";
  const badgeHtml = p.discountLabel ? '<span class="pcard__badge">' + esc(p.discountLabel) + "</span>" : "";
  const gameHtml = p.game ? '<p class="pcard__game">' + esc(p.game) + "</p>" : "";
  const oldPriceHtml = p.originalPrice ? '<s class="pcard__price-old">' + esc(p.originalPrice) + "</s>" : "";
  const notesHtml = (p.notes || []).map((n) => "<li>" + esc(n) + "</li>").join("");
  const link = waLink(contact, "Halo, saya minat sama " + p.name);

  return (
    '<article class="pcard">' +
    '<div class="pcard__stage' +
    (p.image ? "" : " pcard__stage--empty") +
    '">' +
    imgHtml +
    badgeHtml +
    "</div>" +
    '<div class="pcard__body">' +
    gameHtml +
    '<h3 class="pcard__name">' +
    esc(p.name) +
    "</h3>" +
    '<div class="pcard__price">' +
    oldPriceHtml +
    "<span>" +
    esc(p.price) +
    "</span></div>" +
    (notesHtml ? '<ul class="pcard__notes">' + notesHtml + "</ul>" : "") +
    '<a class="pcard__cta" href="' +
    link +
    '" target="_blank" rel="noreferrer" data-product="' +
    esc(p.name) +
    '">' +
    WA_SVG +
    " Beli sekarang</a>" +
    "</div>" +
    "</article>"
  );
}

function renderGrid(elId, products, contact) {
  const el = document.getElementById(elId);
  if (!products || !products.length) {
    el.innerHTML = '<p class="loading-text">Belum ada produk di kategori ini.</p>';
    return;
  }
  el.innerHTML = products.map((p) => renderProductCard(p, contact)).join("");
}

function renderStockTable(fruitStock) {
  const el = document.getElementById("stock-table");
  const rows = (fruitStock || [])
    .map(
      (item) =>
        '<div class="stock-table__row">' +
        '<span class="stock-table__name">' +
        esc(item.name) +
        "</span>" +
        '<span class="stock-table__qty">' +
        esc(item.qty) +
        "</span>" +
        '<span class="stock-table__price">' +
        esc(item.price) +
        "</span>" +
        "</div>"
    )
    .join("");
  el.insertAdjacentHTML("beforeend", rows);
}

function renderJokiFlow(steps) {
  const el = document.getElementById("joki-flow");
  el.innerHTML = (steps || [])
    .map(
      (step, i) =>
        '<li class="joki-flow__step"><span class="joki-flow__num">' +
        (i + 1) +
        '</span><span class="joki-flow__text">' +
        esc(step) +
        "</span></li>"
    )
    .join("");
}

function showToast(message) {
  const toast = document.getElementById("toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(window.__toastTimer);
  window.__toastTimer = setTimeout(() => toast.classList.remove("show"), 2600);
}

async function loadStore() {
  let data;
  try {
    const res = await fetch("/api/products");
    data = await res.json();
  } catch (err) {
    document.getElementById("grid-blox").innerHTML =
      '<p class="loading-text">Gagal memuat data toko. Coba refresh halaman.</p>';
    return;
  }

  const shop = data.shop || {};
  const contact = shop.contact || "";

  document.getElementById("logo-header").src = shop.logo || "";
  document.getElementById("logo-footer").src = shop.logo || "";

  const heroTitleEl = document.getElementById("hero-title");
  heroTitleEl.innerHTML = esc(shop.heroTitle || "").replace(/\n/g, "<br>");
  document.getElementById("hero-sub").textContent = shop.heroSub || "";

  document.getElementById("cta-header").href = waLink(contact);
  document.getElementById("cta-hero").href = waLink(contact);
  document.getElementById("cta-footer").href = waLink(contact);
  document.getElementById("cta-footer").textContent = contact;
  document.getElementById("payment-rule").textContent = shop.paymentRule || "";

  // hero showcase = produk pertama dari blox fruit yang punya gambar (fallback ke produk lain)
  const heroProduct =
    (data.bloxFruit || []).find((p) => p.image) ||
    (data.otherGames || []).find((p) => p.image);
  if (heroProduct) {
    document.getElementById("hero-product-img").src = heroProduct.image;
    document.getElementById("hero-product-img").alt = heroProduct.name;
    document.getElementById("hero-caption").innerHTML =
      esc(heroProduct.name) + ' <span>&middot; ' + esc(heroProduct.price) + "</span>";
  }

  renderGrid("grid-blox", data.bloxFruit, contact);
  renderGrid("grid-other", data.otherGames, contact);
  renderStockTable(data.fruitStock);

  const joki = data.joki || {};
  document.getElementById("joki-title").textContent = joki.title || "";
  document.getElementById("joki-description").textContent = joki.description || "";
  document.getElementById("cta-joki").href = waLink(contact, "Halo, saya mau tanya soal jasa joki");
  renderJokiFlow(joki.flow);

  document.getElementById("footer-year").textContent = "© " + new Date().getFullYear() + " " + (shop.name || "");

  document.body.addEventListener("click", (e) => {
    const cta = e.target.closest("a.pcard__cta, a#cta-hero, a#cta-header, a#cta-joki");
    if (cta) {
      const label = cta.getAttribute("data-product");
      showToast(label ? "Membuka WhatsApp untuk " + label + "..." : "Membuka WhatsApp admin...");
    }
  });
}

document.addEventListener("DOMContentLoaded", loadStore);
